//Disclaimer, I went through forums and documentation to find a decent chunk of the logic here


//Link HTML elements within body to display game
const playerHand = document.getElementById("playerHand")
const computerHand = document.getElementById("computerHand")
const dealerScoreTracker = document.getElementById("dealerScoreTracker")
const playerScoreTracker = document.getElementById("playerScoreTracker")
const deck = document.getElementById("deck")
const statusText = document.getElementById("statusText")

//Link buttons for deciding how to play
const stayBtn = document.getElementById("stayBtn")
const hitBtn = document.getElementById("hitBtn")
const startBtn = document.getElementById("startBtn")

//Create gameplay variables
var playerScore = 0
var computerScore = 0

var playerCards = []
var dealerCards = []
var deckCards = []

//Card definitions
const suits = ["♠","♥","♦","♣"]
const values = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"]


//Create deck
function createDeck()
{
    deckCards = []

    var suitIndex = 0
    var valueIndex = 0

    for(suitIndex = 0; suitIndex < suits.length; suitIndex++)
    {
        for(valueIndex = 0; valueIndex < values.length; valueIndex++)
        {
            var card = {
                suit: suits[suitIndex],
                value: values[valueIndex]
            }

            deckCards.push(card)
        }
    }
}


//Shuffle deck
function shuffleDeck()
{
    var i
    var j
    var temp

    for(i = deckCards.length - 1; i > 0; i--)
    {
        j = Math.floor(Math.random() * (i + 1))

        temp = deckCards[i]
        deckCards[i] = deckCards[j]
        deckCards[j] = temp
    }
}


//Draw card from deck
function drawCard()
{
    var card = deckCards.pop()
    return card
}


//Calculate score
function calculateScore(cards)
{
    var score = 0
    var aces = 0
    var i
    var card

    for(i = 0; i < cards.length; i++)
    {
        card = cards[i]

        if(card.value === "A")
        {
            score = score + 11
            aces = aces + 1
        }
        else if(card.value === "K" || card.value === "Q" || card.value === "J")
        {
            score = score + 10
        }
        else
        {
            score = score + parseInt(card.value)
        }
    }

    while(score > 21 && aces > 0)
    {
        score = score - 10
        aces = aces - 1
    }

    return score
}


//Render cards visually
function renderHands()
{
    playerHand.innerHTML = ""
    computerHand.innerHTML = ""

    var i
    var card
    var div

    for(i = 0; i < playerCards.length; i++)
    {
        card = playerCards[i]

        div = document.createElement("div")
        div.classList.add("card")
        div.textContent = card.value + card.suit

        playerHand.appendChild(div)
    }

    for(i = 0; i < dealerCards.length; i++)
    {
        card = dealerCards[i]

        div = document.createElement("div")
        div.classList.add("card")
        div.textContent = card.value + card.suit

        computerHand.appendChild(div)
    }

    //Save hand data in HTML
    playerHand.dataset.cards = JSON.stringify(playerCards)
    computerHand.dataset.cards = JSON.stringify(dealerCards)
}


//Update score trackers
function updateScores()
{
    playerScore = calculateScore(playerCards)
    computerScore = calculateScore(dealerCards)

    playerScoreTracker.textContent = "Player Score: " + playerScore
    dealerScoreTracker.textContent = "Dealer Score: " + computerScore
}


//Check game over conditions
function checkGameOver()
{
    if(playerScore === 21)
    {
        statusText.textContent = "Blackjack! You Win!"
        disableButtons()
    }

    if(playerScore > 21)
    {
        statusText.textContent = "Bust! You Lose!"
        disableButtons()
    }
}


//Dealer turn logic
function dealerTurn()
{
    computerScore = calculateScore(dealerCards)

    while(computerScore < 17)
    {
        var newCard = drawCard()
        dealerCards.push(newCard)

        computerScore = calculateScore(dealerCards)
    }

    updateScores()
    renderHands()

    determineWinner()
}


//Determine winner
function determineWinner()
{
    if(computerScore > 21)
    {
        statusText.textContent = "Dealer Busts! You Win!"
    }
    else if(playerScore > computerScore)
    {
        statusText.textContent = "You Win!"
    }
    else if(playerScore < computerScore)
    {
        statusText.textContent = "Dealer Wins!"
    }
    else
    {
        statusText.textContent = "Push (Tie)"
    }

    disableButtons()
}


//Disable buttons after game ends
function disableButtons()
{
    hitBtn.disabled = true
    stayBtn.disabled = true
}


//Start new game
function startGame()
{
    playerCards = []
    dealerCards = []

    createDeck()
    shuffleDeck()

    var firstCard
    var secondCard

    firstCard = drawCard()
    secondCard = drawCard()

    playerCards.push(firstCard)
    playerCards.push(secondCard)

    firstCard = drawCard()
    secondCard = drawCard()

    dealerCards.push(firstCard)
    dealerCards.push(secondCard)

    updateScores()
    renderHands()

    statusText.textContent = "Your move!"

    hitBtn.disabled = false
    stayBtn.disabled = false
}


//Hit button action
function hitAction()
{
    var newCard = drawCard()

    playerCards.push(newCard)

    updateScores()
    renderHands()

    checkGameOver()
}


//Stay button action
function stayAction()
{
    dealerTurn()
}


//Attach button listeners
hitBtn.addEventListener("click", hitAction)
stayBtn.addEventListener("click", stayAction)


//Start game when page loads
startGame()